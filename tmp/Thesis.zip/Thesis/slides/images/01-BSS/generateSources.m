close all;

t = 0:0.001:1;
d2 = (repmat(t',1,length(t))-repmat(t,length(t),1)).^2;


y = zeros(4,length(t));
var_vec = [7e-4 1e-3 1e-3 3e-3];
for k=1:4
    K = exp(-d2/var_vec(k));
    y(k,:) = mvnrnd2(zeros(size(t)),K,1);
    
    figure;
    h = plot(t,y(k,:));
    set(h,'LineWidth',1.2);
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    figurapdf(1,0.45);
    print('-dpdf',['Source' num2str(k) '.pdf']);
end

figure;
h = plot(t,sum(y,1));
set(h,'LineWidth',1.2);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
figurapdf(1,0.45);
print('-dpdf','SourceAll.pdf');
