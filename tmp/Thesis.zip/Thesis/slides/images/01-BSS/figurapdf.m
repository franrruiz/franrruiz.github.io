function figurapdf(ancho, alto)
set(gcf, 'papersize', [ancho alto]);
set(gcf, 'paperposition', [0 0 ancho alto]);
